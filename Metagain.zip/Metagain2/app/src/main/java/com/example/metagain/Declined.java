package com.example.metagain;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Declined extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_declined);
    }
}